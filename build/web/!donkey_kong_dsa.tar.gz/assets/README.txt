Donkey Kong: DSA Edition - web (pygbag) version

Build (needs internet, Python 3.10+):
  pip install pygbag
  pygbag --archive donkey_kong_dsa       (run from the folder that CONTAINS donkey_kong_dsa)

Test locally first:
  pygbag donkey_kong_dsa                 then open http://localhost:8000

Upload:
  itch.io  -> upload build/web.zip, kind of project = HTML, tick "SharedArrayBuffer"/fullscreen as you like
  GitHub Pages / Netlify / Vercel -> upload the contents of build/web
