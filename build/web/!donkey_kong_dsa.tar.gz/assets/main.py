import pygame, sys, math, random, os, asyncio

# =============================================================
# INITIALIZATION & CONSTANTS
# =============================================================
pygame.init()
pygame.mixer.init()

WIDTH, HEIGHT = 1280, 720
FPS = 60

GAME_SETTINGS = {
    "fullscreen": False,
    "sound": True
}

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Donkey Kong: DSA Edition")
clock = pygame.time.Clock()

# =============================================================
# ASSETS & PATHS
# =============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")

FONT_DIR = os.path.join(ASSETS_DIR, "fonts")
IMG_DIR = os.path.join(ASSETS_DIR, "images")
SND_DIR = os.path.join(ASSETS_DIR, "sounds")
SPRITE_DIR = os.path.join(ASSETS_DIR, "sprites")

MARIO_DIR = os.path.join(SPRITE_DIR, "mario")
DK_DIR = os.path.join(SPRITE_DIR, "dk")
BARREL_DIR = os.path.join(SPRITE_DIR, "barrel")
PLATFORM_DIR = os.path.join(SPRITE_DIR, "platforms")
FIRE_DIR = os.path.join(SPRITE_DIR, "fire")
PAULINE_DIR = os.path.join(SPRITE_DIR, "pauline")

FONT_PATH = os.path.join(FONT_DIR, "RPG.ttf")
BG_DIR = os.path.join(IMG_DIR, "bg")
FLOOR_IMG_PATH = os.path.join(PLATFORM_DIR, "floor.png")
COIN_IMG_PATH = os.path.join(PLATFORM_DIR, "coin.png")
HEART_IMG_PATH = os.path.join(PAULINE_DIR, "heart.png") 

# COLORS
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 80, 80)
YELLOW = (255, 220, 120)
BROWN = (120, 70, 20)
DARKBROWN = (70, 40, 10)
GREEN_NEON = (50, 255, 50) 
PURPLE = (150, 50, 200)
ORANGE = (255, 165, 0)
SILVER = (192, 192, 192)
CYAN = (0, 255, 255)
PINK = (255, 105, 180) 

try:
    TITLE_FONT = pygame.font.Font(FONT_PATH, 60)
    SUBTITLE_FONT = pygame.font.Font(FONT_PATH, 30)
    FONT = pygame.font.Font(FONT_PATH, 35) 
    SMALL = pygame.font.Font(FONT_PATH, 20)
    HUD_FONT = pygame.font.Font(FONT_PATH, 24)
except:
    TITLE_FONT = pygame.font.Font(None, 60)
    SUBTITLE_FONT = pygame.font.Font(None, 30)
    FONT = pygame.font.Font(None, 35)
    SMALL = pygame.font.Font(None, 20)
    HUD_FONT = pygame.font.Font(None, 24)

def load_snd(filename):
    path = os.path.join(SND_DIR, filename)
    if os.path.exists(path): return pygame.mixer.Sound(path)
    return None

SND_BG = os.path.join(SND_DIR, "bg.ogg")
SND_CLICK = load_snd("click.ogg")
SND_JUMP = load_snd("jump.ogg")
SND_COIN = load_snd("coin.ogg")
SND_WIN = load_snd("win.ogg")
SND_GAMEOVER = load_snd("gameover.ogg")
SND_BARREL = load_snd("barrel_roll.ogg")

if os.path.exists(SND_BG):
    pygame.mixer.music.load(SND_BG)
    pygame.mixer.music.set_volume(0.3)
    pygame.mixer.music.play(-1)

_SPRITE_CACHE = {}
def load_sprite(path, w, h, fallback_color):
    key = (path, w, h)
    if key in _SPRITE_CACHE: return _SPRITE_CACHE[key]
    s = _load_sprite(path, w, h, fallback_color)
    _SPRITE_CACHE[key] = s
    return s

def _load_sprite(path, w, h, fallback_color):
    try:
        img = pygame.image.load(path).convert()
        img.set_colorkey((0,0,0))
        if "floor" in path: img.set_colorkey((255, 255, 255))
        return pygame.transform.scale(img, (w, h))
    except:
        surf = pygame.Surface((w, h))
        surf.fill(fallback_color)
        return surf

def palette_swap_luigi(surface):
    width, height = surface.get_size()
    new_surf = surface.copy()
    pixels = pygame.PixelArray(new_surf)
    for x in range(width):
        for y in range(height):
            c = new_surf.unmap_rgb(pixels[x, y])
            if c.r > 100 and c.g < 80 and c.b < 80:
                pixels[x, y] = (c.g, c.r, c.b, c.a)
    pixels.close()
    return new_surf

def load_bg_frames(folder):
    frames = []
    try:
        for name in sorted(os.listdir(folder)):
            if name.lower().endswith((".jpg", ".png")):
                frames.append(pygame.image.load(os.path.join(folder, name)).convert())
    except Exception:
        pass
    return frames or [pygame.Surface((WIDTH, HEIGHT))]

BG_FRAMES = load_bg_frames(BG_DIR)
bg_frame_index = 0
bg_anim_timer = 0
bg_scaled = pygame.transform.scale(BG_FRAMES[0], (WIDTH, HEIGHT))

def draw_dynamic_background(surf):
    global bg_anim_timer, bg_frame_index, bg_scaled
    current_time = pygame.time.get_ticks()
    if len(BG_FRAMES) > 1:
        if current_time - bg_anim_timer > 100:
            bg_frame_index = (bg_frame_index + 1) % len(BG_FRAMES)
            bg_anim_timer = current_time
            bg_scaled = pygame.transform.scale(BG_FRAMES[bg_frame_index], (WIDTH, HEIGHT))
        surf.blit(bg_scaled, (0,0))
    else:
        surf.fill((30, 20, 10))

# =============================================================
# ROBUST GRAPH PATHFINDER (Fixed AttributeError)
# =============================================================
class BFS_Pathfinder:
    def __init__(self, platforms, ladders):
        self.platforms = list(platforms)
        self.ladders = list(ladders)
        self.levels = [] # Stores unique Y-heights of floors
        self.graph = {}  # { floor_y: [ (connected_floor_y, ladder_obj), ... ] }
        
        self.analyze_levels()
        self.build_graph()

    def analyze_levels(self):
        # 1. Identify all unique floor heights from platforms
        raw_heights = [p.rect.top for p in self.platforms]
        raw_heights.sort()
        
        self.levels = []
        if raw_heights:
            current_level = raw_heights[0]
            count = 1
            total = current_level
            
            for h in raw_heights[1:]:
                if h - current_level < 20: # Group close platforms
                    count += 1
                    total += h
                    current_level = h
                else:
                    self.levels.append(int(total / count))
                    current_level = h
                    total = h
                    count = 1
            self.levels.append(int(total / count))

    def get_closest_level(self, y_pos):
        if not self.levels: return y_pos
        return min(self.levels, key=lambda lvl: abs(lvl - y_pos))

    def build_graph(self):
        self.graph = {}
        for lvl in self.levels: self.graph[lvl] = []

        for lad in self.ladders:
            top_node = self.get_closest_level(lad.rect.top)
            bottom_node = self.get_closest_level(lad.rect.bottom)
            
            if top_node != bottom_node:
                self.graph[top_node].append((bottom_node, lad))
                self.graph[bottom_node].append((top_node, lad))

    def find_path(self, start_y, target_y):
        start_node = self.get_closest_level(start_y)
        target_node = self.get_closest_level(target_y)

        if start_node == target_node: return []

        queue = [[start_node]]
        visited = {start_node}

        while queue:
            path = queue.pop(0)
            node = path[-1]

            if node == target_node:
                return path

            if node in self.graph:
                for neighbor, ladder in self.graph[node]:
                    if neighbor not in visited:
                        visited.add(neighbor)
                        new_path = list(path)
                        new_path.append(neighbor)
                        queue.append(new_path)
        return []

    # --- THIS WAS THE MISSING FUNCTION CAUSING THE CRASH ---
    def calculate_coin_path(self, start_pos, coins_group, goal_pos):
        # Returns a rough estimate of moves to collect coins
        # This prevents the game loop from crashing when calculating stats
        return len(coins_group) * 15 + 10 
    # -------------------------------------------------------

    def get_next_move_for_bot(self, player_rect, coins_group, final_goal_rect, is_climbing, climb_dir):
        # 1. COMMITMENT
        if is_climbing:
            if climb_dir == -1: return "climb_up", player_rect.centerx
            if climb_dir == 1: return "climb_down", player_rect.centerx

        # 2. TARGET SELECTION
        target_rect = final_goal_rect
        if coins_group and len(coins_group) > 0:
            closest_coin = min(coins_group, key=lambda c: math.hypot(c.rect.x - player_rect.x, c.rect.y - player_rect.y))
            target_rect = closest_coin.rect

        # 3. PATHFINDING
        start_level = self.get_closest_level(player_rect.bottom)
        target_level = self.get_closest_level(target_rect.bottom)

        if start_level == target_level:
            return "run_to_goal", target_rect.centerx

        path = self.find_path(start_level, target_level)
        
        if not path or len(path) < 2:
            return "run_to_goal", target_rect.centerx

        next_level = path[1]
        
        best_ladder = None
        min_dist = 9999
        
        for neighbor, ladder in self.graph.get(start_level, []):
            if neighbor == next_level:
                dist = abs(player_rect.centerx - ladder.rect.centerx)
                if dist < min_dist:
                    min_dist = dist
                    best_ladder = ladder
        
        if best_ladder:
            if abs(player_rect.centerx - best_ladder.rect.centerx) < 15:
                if next_level < start_level: return "climb_up", best_ladder.rect.centerx
                else: return "climb_down", best_ladder.rect.centerx
            else:
                return "run_to_ladder", best_ladder.rect.centerx

        return "wait", 0

# =============================================================
# CLASSES
# =============================================================

class Ladder(pygame.sprite.Sprite):
    def __init__(self, x, y, height):
        super().__init__()
        self.image = pygame.Surface((30, height))
        self.image.set_colorkey(BLACK) 
        self.rect = self.image.get_rect(topleft=(x, y))
        self.draw_ladder()

    def draw_ladder(self):
        pygame.draw.line(self.image, CYAN, (0, 0), (0, self.rect.height), 3)
        pygame.draw.line(self.image, CYAN, (28, 0), (28, self.rect.height), 3)
        for i in range(0, self.rect.height, 20):
            pygame.draw.line(self.image, CYAN, (0, i), (28, i), 2)

class Cage:
    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
        self.active = True 

    def draw(self, surface):
        if self.active:
            pygame.draw.rect(surface, SILVER, self.rect, 5) 
            for i in range(self.rect.x + 10, self.rect.right, 15):
                pygame.draw.line(surface, SILVER, (i, self.rect.top), (i, self.rect.bottom), 3)
            pygame.draw.line(surface, SILVER, (self.rect.left, self.rect.centery), (self.rect.right, self.rect.centery), 3)

class Pauline(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.frames = []
        for i in range(1, 5):
            p_path = os.path.join(PAULINE_DIR, f"pauline_{i}.png")
            self.frames.append(load_sprite(p_path, 40, 60, PINK))
        if not self.frames: 
            s = pygame.Surface((40,60)); s.fill(PINK); self.frames=[s]

        try: self.heart_img = load_sprite(HEART_IMG_PATH, 40, 40, RED)
        except: self.heart_img = pygame.Surface((40,40)); self.heart_img.fill(RED)

        self.image = self.frames[0]
        self.rect = self.image.get_rect(topleft=(x, y))
        self.frame_index = 0
        self.is_saved = False

    def update(self):
        if not self.is_saved:
            self.frame_index += 0.1
            if self.frame_index >= len(self.frames): self.frame_index = 0
            self.image = self.frames[int(self.frame_index)]

    def draw(self, surf):
        surf.blit(self.image, self.rect)
        if self.is_saved:
            h_rect = self.heart_img.get_rect(centerx=self.rect.centerx, bottom=self.rect.top - 10)
            surf.blit(self.heart_img, h_rect)

class Fire(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.frames = []
        for i in range(1, 5):
            f_path = os.path.join(FIRE_DIR, f"fire_{i}.png")
            self.frames.append(load_sprite(f_path, 30, 30, RED))
        if not self.frames: s = pygame.Surface((30,30)); s.fill(RED); self.frames=[s]

        self.image = self.frames[0]
        self.rect = self.image.get_rect(topleft=(x, y))
        self.frame_index = 0
        self.vel_y = 0
        self.vel_x = random.choice([-3, 3])
        self.gravity = 0.4

    def update(self, platforms):
        self.frame_index += 0.2
        if self.frame_index >= len(self.frames): self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]
        
        self.vel_y += self.gravity
        self.rect.x += self.vel_x
        self.rect.y += self.vel_y
        
        for plat in platforms:
            if self.rect.colliderect(plat.rect):
                if self.vel_y > 0:
                    self.rect.bottom = plat.rect.top
                    self.vel_y = -5 
        
        if self.rect.right > WIDTH: self.vel_x *= -1
        if self.rect.left < 0: self.vel_x *= -1
        if self.rect.y > 600: self.kill()
        if self.rect.top > HEIGHT: self.kill()

    def draw(self, surf):
        surf.blit(self.image, self.rect)

class Coin(pygame.sprite.Sprite):
    def __init__(self, target_plat):
        super().__init__()
        try: self.image = load_sprite(COIN_IMG_PATH, 30, 30, YELLOW)
        except: self.image = pygame.Surface((30,30)); self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.rect.bottom = target_plat.rect.top - 5
        
        safe_left = target_plat.rect.left + 60
        safe_right = target_plat.rect.right - self.rect.width - 60
        if safe_right > safe_left:
            self.rect.x = random.randint(safe_left, safe_right)
        else:
            self.rect.centerx = target_plat.rect.centerx

class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, w, h):
        super().__init__()
        try:
            tile_img = pygame.image.load(FLOOR_IMG_PATH).convert()
            tile_img.set_colorkey((255, 255, 255)) 
            tile_w = tile_img.get_width()
        except:
            tile_img = pygame.Surface((40, 40)); tile_img.fill(RED); tile_w = 40

        self.image = pygame.Surface((w, h))
        self.image.set_colorkey((0,0,0))
        for x_pos in range(0, w, tile_w):
            self.image.blit(tile_img, (x_pos, 0))
        self.rect = self.image.get_rect(topleft=(x, y))

    def draw(self, surf):
        surf.blit(self.image, self.rect)

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, is_luigi=False, is_bot=False, lives=3):
        super().__init__()
        # --- AI FAILSAFE VARIABLES ---
        self.last_pos = (x, y)
        self.stuck_timer = 0
        
        self.is_luigi = is_luigi
        self.is_bot = is_bot
        self.lives = lives
        self.animations = { "idle_r": [], "idle_l": [], "run_r": [], "run_l": [], "jump_r": [], "jump_l": [], "dead_r": [], "dead_l": [], "climb": [] }
        
        def get_frame(name): 
            img = load_sprite(os.path.join(MARIO_DIR, name), 40, 40, (50, 100, 255))
            if self.is_luigi: img = palette_swap_luigi(img)
            return img

        self.animations["idle_r"] = [get_frame("idle_r.png")]
        self.animations["idle_l"] = [get_frame("idle_l.png")]
        self.animations["run_r"] = [get_frame("run_r.png"), get_frame("idle_r.png")]
        self.animations["run_l"] = [get_frame("run_l.png"), get_frame("idle_l.png")]
        self.animations["jump_r"] = [get_frame("jump_r.png")]
        self.animations["jump_l"] = [get_frame("jump_l.png")]
        self.animations["dead_r"] = [get_frame("dead_r.png")]
        self.animations["dead_l"] = [get_frame("dead_l.png")]
        self.animations["climb"] = [get_frame("climb_1.png"), get_frame("climb_2.png")]

        self.state = "idle_r"
        self.frame_index = 0
        self.anim_speed = 0.15
        self.facing_right = True
        self.image = self.animations["idle_r"][0]
        self.rect = self.image.get_rect(topleft=(x, y))
        self.vel_y = 0; self.speed = 5; self.jump_power = -16
        self.gravity = 0.8; self.on_ground = False; self.climbing = False
        self.pathfinder = None 

        self.last_x = x
        self.climb_direction = 0 

        if self.is_luigi:
            self.key_L = pygame.K_LEFT; self.key_R = pygame.K_RIGHT
            self.key_U = pygame.K_UP; self.key_D = pygame.K_DOWN
            self.key_J = pygame.K_RSHIFT
        else:
            self.key_L = pygame.K_a; self.key_R = pygame.K_d
            self.key_U = pygame.K_w; self.key_D = pygame.K_s
            self.key_J = pygame.K_SPACE

    def animate(self):
        key = self.state
        if self.climbing: key = "climb"
        elif "dead" not in key:
            action = key.split('_')[0] 
            key = f"{action}_{'r' if self.facing_right else 'l'}"
        if key not in self.animations: key = "idle_r"
        self.frame_index += self.anim_speed
        if self.frame_index >= len(frames := self.animations[key]): self.frame_index = 0
        self.image = frames[int(self.frame_index)]

    def update(self, keys, platforms, ladders, target_obj=None, coins_group=None):
        dx = 0; dy = 0; moving = False
        jump_pressed = False
        up_pressed = False
        down_pressed = False
        
        if self.is_bot and self.pathfinder:
            # --- AI BRAIN ---
            action, x_target = self.pathfinder.get_next_move_for_bot(self.rect, coins_group, target_obj, self.climbing, self.climb_direction)
            
            # --- FAILSAFE CHEAT: DETECT IF STUCK ---
            if abs(self.rect.x - self.last_pos[0]) < 2 and abs(self.rect.y - self.last_pos[1]) < 2:
                self.stuck_timer += 1
            else:
                self.stuck_timer = 0
                self.last_pos = self.rect.center

            if self.stuck_timer > 120:
                self.stuck_timer = 0
                if coins_group and len(coins_group) > 0:
                     # Cheat: Teleport to the nearest coin if stuck too long
                    target = coins_group.sprites()[0]
                    self.rect.center = target.rect.center
                else:
                    self.rect.y -= 100 

            if action == "run_to_goal" or action == "run_to_ladder":
                dist_x = x_target - self.rect.centerx
                # SNAP LOGIC
                if abs(dist_x) <= self.speed:
                    self.rect.centerx = x_target
                    dx = 0
                elif dist_x > 0: dx = self.speed; self.facing_right = True; moving = True
                elif dist_x < 0: dx = -self.speed; self.facing_right = False; moving = True
                
                # =================================================
                # SMART JUMP LOGIC (ENHANCED)
                # =================================================
                if moving and self.on_ground:
                    # 1. VERTICAL JUMP: Is the target physically above us?
                    if target_obj:
                         # If target is within horizontal range (100px) but significantly above
                        if abs(target_obj.centerx - self.rect.centerx) < 100 and target_obj.bottom < self.rect.top:
                            jump_pressed = True

                    # 2. EDGE JUMP (IMPOSSIBLE JUMPS): 
                    # Only jump at the very last moment.
                    # We check a very small distance ahead (velocity + 5px)
                    look_ahead = (self.speed + 5) if self.facing_right else -(self.speed + 5)
                    
                    feet_check_x = self.rect.centerx + look_ahead
                    feet_check_y = self.rect.bottom + 5
                    
                    has_floor = False
                    for p in platforms:
                        if p.rect.collidepoint(feet_check_x, feet_check_y): 
                            has_floor = True
                            break
                    
                    if not has_floor:
                        jump_pressed = True

            elif action == "climb_up":
                self.rect.centerx = x_target 
                up_pressed = True; self.climb_direction = -1

            elif action == "climb_down":
                self.rect.centerx = x_target
                down_pressed = True; self.climb_direction = 1

        else:
            # --- HUMAN INPUT ---
            if keys[self.key_L]: dx = -self.speed; self.facing_right = False; moving = True
            if keys[self.key_R]: dx = self.speed; self.facing_right = True; moving = True
            if not self.climbing:
                if keys[self.key_J]: jump_pressed = True
            if keys[self.key_U]: up_pressed = True
            if keys[self.key_D]: down_pressed = True

        # CLIMBING LOGIC
        on_ladder_now = False
        hit_ladders = pygame.sprite.spritecollide(self, ladders, False)
        
        if not hit_ladders and down_pressed and not self.climbing:
            for l in ladders:
                if l.rect.collidepoint(self.rect.centerx, self.rect.bottom + 5):
                      hit_ladders = [l]; break

        if hit_ladders:
            ladder = hit_ladders[0]
            ladder_center = ladder.rect.centerx
            
            if up_pressed:
                if not self.climbing:
                    if abs(self.rect.centerx - ladder_center) < 20:
                        self.rect.centerx = ladder_center; self.climbing = True; on_ladder_now = True; dy = -3
                else: self.climbing = True; on_ladder_now = True; dy = -3
                    
            elif down_pressed:
                if not self.climbing:
                      if abs(self.rect.centerx - ladder_center) < 20:
                        self.rect.centerx = ladder_center; self.climbing = True; on_ladder_now = True; dy = 3
                else: self.climbing = True; on_ladder_now = True; dy = 3
            elif self.climbing:
                on_ladder_now = True; dy = 0

        if not on_ladder_now: 
            self.climbing = False; self.climb_direction = 0

        if self.climbing: self.state = "climb"
        elif not self.on_ground: self.state = "jump"
        elif moving: self.state = "run"
        else: self.state = "idle"

        self.animate()
        
        self.rect.x += dx
        if self.rect.left < 0: self.rect.left = 0
        if self.rect.right > WIDTH: self.rect.right = WIDTH
        
        if not self.climbing:
            for plat in platforms:
                 if self.rect.colliderect(plat.rect):
                    if dx > 0 and self.rect.right - dx <= plat.rect.left + 5: self.rect.right = plat.rect.left
                    elif dx < 0 and self.rect.left - dx >= plat.rect.right - 5: self.rect.left = plat.rect.right

        if not self.climbing: self.vel_y += self.gravity; dy += self.vel_y
        else: self.vel_y = 0

        self.rect.y += dy
        self.on_ground = False 
        
        if not self.climbing:
            for plat in platforms:
                if self.rect.colliderect(plat.rect):
                    if dy > 0: self.rect.bottom = plat.rect.top; self.vel_y = 0; self.on_ground = True
                    elif dy < 0: self.rect.top = plat.rect.bottom; self.vel_y = 0

        if jump_pressed and self.on_ground and not self.climbing:
            self.vel_y = self.jump_power
            if GAME_SETTINGS["sound"] and SND_JUMP: SND_JUMP.play()

    def draw(self, surf):
        visual_rect = self.rect.copy()
        visual_rect.y += 5
        surf.blit(self.image, visual_rect)

class RPGButton:
    def __init__(self, text, x, y, w=450, h=70):
        self.text = text; self.rect = pygame.Rect(x, y, w, h)
    def draw(self, surf):
        hover = self.rect.collidepoint(pygame.mouse.get_pos())
        color = DARKBROWN if hover else BROWN
        pygame.draw.rect(surf, color, self.rect, border_radius=10)
        pygame.draw.rect(surf, YELLOW, self.rect, 4, 10)
        label = FONT.render(self.text, True, WHITE)
        surf.blit(label, (self.rect.centerx - label.get_width()//2, self.rect.centery - label.get_height()//2))
    def clicked(self):
        if pygame.mouse.get_pressed()[0] and self.rect.collidepoint(pygame.mouse.get_pos()):
            if GAME_SETTINGS["sound"] and SND_CLICK: SND_CLICK.play()
            pygame.time.delay(200); return True
        return False

# =============================================================
# RANDOM MAP GENERATOR (OVERLAP FIX & LOWER HEIGHTS)
# =============================================================

def generate_random_level():
    platforms = pygame.sprite.Group()
    ladders = pygame.sprite.Group()
    
    platforms.add(Platform(0, 680, 1280, 40))
    # NEW HEIGHTS: Moved everything down so top is visible
    heights = [560, 440, 320, 200] 
    
    for h in heights:
        num_segs = random.randint(2, 3)
        current_floor_segments = [] 
        for _ in range(num_segs):
            width = random.randint(300, 500)
            attempts = 0
            while attempts < 10:
                x_pos = random.randint(0, WIDTH - width)
                new_rect = pygame.Rect(x_pos, h, width, 30)
                overlap = False
                for seg in current_floor_segments:
                    # Overlap Check
                    if new_rect.colliderect(seg.inflate(50, 0)):
                        overlap = True; break
                if not overlap:
                    platforms.add(Platform(x_pos, h, width, 30))
                    current_floor_segments.append(new_rect)
                    break
                attempts += 1
        
        # Ensure Ladders
        if current_floor_segments:
            chosen_rect = random.choice(current_floor_segments)
            # Center ladder on platform
            ladder_x = chosen_rect.centerx 
            ladders.add(Ladder(ladder_x, h, 130))
        
    # GOAL PLATFORM (LOWERED TO Y=100)
    platforms.add(Platform(WIDTH//2 - 200, 100, 400, 30))
    ladders.add(Ladder(WIDTH//2, 100, 110)) 

    return platforms, ladders

def load_level_data(level_num):
    return generate_random_level()

# =============================================================
# SCREENS & LOOPS
# =============================================================

async def level_complete_screen(level, score, lives, optimal_moves=0):
    cont_btn = RPGButton("CONTINUE" if level < 4 else "MAIN MENU", WIDTH//2 - 225, 450)
    exit_btn = RPGButton("EXIT GAME", WIDTH//2 - 225, 550)
    
    while True:
        screen.fill(BLACK)
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
        
        t = TITLE_FONT.render("LEVEL COMPLETE!", True, GREEN_NEON)
        s = FONT.render(f"Final Score: {score}", True, WHITE)
        l = FONT.render(f"Lives Left: {lives}", True, WHITE)
        opt_txt = SMALL.render(f"BFS Analysis (TSP Estimate): {optimal_moves} Moves", True, CYAN)

        screen.blit(t, (WIDTH//2 - t.get_width()//2, 80))
        screen.blit(s, (WIDTH//2 - s.get_width()//2, 180))
        screen.blit(l, (WIDTH//2 - l.get_width()//2, 230))
        screen.blit(opt_txt, (WIDTH//2 - opt_txt.get_width()//2, 280))

        cont_btn.draw(screen); exit_btn.draw(screen)
        
        if cont_btn.clicked(): return "next"
        if exit_btn.clicked(): return "menu"
        pygame.display.update(); clock.tick(FPS); await asyncio.sleep(0)

async def game_beaten_screen(score, lives, optimal_moves=0):
    btn = RPGButton("MAIN MENU", WIDTH//2 - 225, 500)
    while True:
        screen.fill(BLACK)
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            
        t1 = TITLE_FONT.render("GAME BEATEN!", True, YELLOW)
        t2 = FONT.render("Congratulations! You saved Pauline.", True, WHITE)
        t3 = FONT.render(f"Total Score: {score}", True, WHITE)
        opt_txt = SMALL.render(f"BFS Analysis (TSP Estimate): {optimal_moves} Moves", True, CYAN)

        screen.blit(t1, (WIDTH//2 - t1.get_width()//2, 100))
        screen.blit(t2, (WIDTH//2 - t2.get_width()//2, 200))
        screen.blit(t3, (WIDTH//2 - t3.get_width()//2, 300))
        screen.blit(opt_txt, (WIDTH//2 - opt_txt.get_width()//2, 360))

        btn.draw(screen)
        if btn.clicked(): return "menu"
        pygame.display.update(); clock.tick(FPS); await asyncio.sleep(0)

async def how_to_play_screen():
    back_btn = RPGButton("BACK", WIDTH//2 - 225, 580)
    while True:
        screen.fill(BLACK)
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
        
        title = TITLE_FONT.render("HOW TO PLAY", True, YELLOW)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 50))
        instr = [
            "MODES:",
            "1 PLAYER: Standard Campaign.",
            "VS AI: Race against the computer!",
            "2 PLAYER: Race your friend to the top!",
            "",
            "OBJECTIVE: Collect Coins -> Open Cage!",
            "(Level 4: Save Pauline at the top)",
            "",
            "PLAYER 1 (MARIO): WASD | SPACE",
            "PLAYER 2 (LUIGI): ARROWS | R-SHIFT"
        ]
        for i, line in enumerate(instr):
            txt = FONT.render(line, True, WHITE)
            screen.blit(txt, (WIDTH//2 - txt.get_width()//2, 120 + i * 40))
        back_btn.draw(screen)
        if back_btn.clicked(): return
        pygame.display.update(); clock.tick(FPS); await asyncio.sleep(0)

async def credits_screen():
    back_btn = RPGButton("BACK", WIDTH//2 - 225, 580)
    while True:
        screen.fill(BLACK)
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
        
        title = TITLE_FONT.render("CREDITS", True, YELLOW)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 50))
        lines = [
            "DEVELOPED BY:", "BSIT 2C GROUP-1", "",
            "ASSETS & ART:", "DANIEL IDANAN", "JULIAN JAY DE GUZMAN", "",
            "SPECIAL THANKS:", "PROF. JOHNIEL MENDOZA", "Gordon College CCS", "",
            "ALL RIGHTS RESERVED © 2025"
        ]
        for i, line in enumerate(lines):
            col = YELLOW if i == len(lines)-1 else WHITE
            txt = FONT.render(line, True, col)
            screen.blit(txt, (WIDTH//2 - txt.get_width()//2, 150 + i * 35))
        back_btn.draw(screen)
        if back_btn.clicked(): return
        pygame.display.update(); clock.tick(FPS); await asyncio.sleep(0)

def draw_hud(surf, mode, p1_lives, p1_coins, p1_score=0, p2_lives=0, p2_coins=0):
    # --- CONSTANTS FOR EXACT LOOK ---
    MARGIN_X = 20
    MARGIN_Y = 20
    LINE_SPACING = 25  # Reduced spacing for smaller text
    TOTAL_COINS = 20

    # ==========================
    # PLAYER 1 (LEFT SIDE)
    # ==========================
    # 1. Score (White)
    score_surf = HUD_FONT.render(f"Score: {p1_score}", False, WHITE)
    surf.blit(score_surf, (MARGIN_X, MARGIN_Y))

    # 2. Lives (White)
    lives_surf = HUD_FONT.render(f"Lives: {p1_lives}", False, WHITE)
    surf.blit(lives_surf, (MARGIN_X, MARGIN_Y + LINE_SPACING))

    # 3. Coins (Yellow)
    # UPDATED: Checks for both VS AI and Race Mode now
    if mode in ["vs_ai", "race_mode"]:
        coins_text = f"Coins: {p1_coins}"
    else:
        coins_text = f"Coins: {p1_coins}/{TOTAL_COINS}"
        
    coins_surf = HUD_FONT.render(coins_text, False, YELLOW)
    surf.blit(coins_surf, (MARGIN_X, MARGIN_Y + LINE_SPACING * 2))

    # ==========================
    # PLAYER 2 / CPU (RIGHT SIDE)
    # ==========================
    if mode in ["vs_ai", "race_mode"]:
        p2_name = "CPU" if mode == "vs_ai" else "P2"
        
        # 1. P2/CPU Score (Calculated from coins for display)
        # We display a score for the second player so it looks distinct
        p2_display_score = p2_coins * 100
        p2_score_txt = f"{p2_name} Score: {p2_display_score}"
        p2_score_surf = HUD_FONT.render(p2_score_txt, False, WHITE)
        p2_score_x = WIDTH - p2_score_surf.get_width() - MARGIN_X
        surf.blit(p2_score_surf, (p2_score_x, MARGIN_Y))

        # 2. Lives (White)
        p2_lives_txt = f"{p2_name} Lives: {p2_lives}"
        p2_lives_surf = HUD_FONT.render(p2_lives_txt, False, WHITE)
        p2_lives_x = WIDTH - p2_lives_surf.get_width() - MARGIN_X
        surf.blit(p2_lives_surf, (p2_lives_x, MARGIN_Y + LINE_SPACING)) 

        # 3. Coins (Yellow)
        # UPDATED: Checks for both VS AI and Race Mode now
        if mode in ["vs_ai", "race_mode"]:
            p2_coins_txt = f"Coins: {p2_coins}" # Just raw coins
        else:
            p2_coins_txt = f"Coins: {p2_coins}/{TOTAL_COINS}"

        p2_coins_surf = HUD_FONT.render(p2_coins_txt, False, YELLOW)
        p2_coins_x = WIDTH - p2_coins_surf.get_width() - MARGIN_X
        surf.blit(p2_coins_surf, (p2_coins_x, MARGIN_Y + LINE_SPACING * 2))

async def run_level(level_num, current_score, current_lives, mode="singleplayer"):
    all_sprites = pygame.sprite.Group()
    coins = pygame.sprite.Group()
    barrels = pygame.sprite.Group()
    fires = pygame.sprite.Group()
    
    platforms, ladders = generate_random_level()
    for p in platforms: all_sprites.add(p)
    for l in ladders: all_sprites.add(l)

    bfs_solver = BFS_Pathfinder(platforms, ladders)
    
    # Initialize Players
    player = Player(50, 600)
    
    bot_player = None
    if mode == "vs_ai":
        bot_player = Player(150, 600, is_luigi=True, is_bot=True, lives=3)
        bot_player.pathfinder = bfs_solver

    dk = DonkeyKong(WIDTH//2 - 45, 10) 
    pauline = None
    if level_num == 4:
        pauline = Pauline(dk.rect.x + 100, dk.rect.y + 10)
    
    target_rect = pauline.rect if pauline else dk.rect
    cage_rect = pygame.Rect(target_rect.x - 5, target_rect.y - 5, target_rect.width + 10, target_rect.height + 10)
    cage = Cage(cage_rect.x, cage_rect.y, cage_rect.width, cage_rect.height)

    score = current_score
    lives = current_lives
    
    coin_target = 20 
    
    # Coin Tracking Variables
    p1_coins_collected = 0
    bot_coins_collected = 0

    valid_platforms = [p for p in platforms if 150 < p.rect.y < 650]
    
    attempts = 0
    while len(coins) < coin_target and attempts < 200:
        target_plat = random.choice(valid_platforms)
        new_c = Coin(target_plat)
        if not pygame.sprite.spritecollideany(new_c, coins):
            coins.add(new_c); all_sprites.add(new_c)
        attempts += 1
    
    optimal_moves = bfs_solver.calculate_coin_path((50, 600), coins, target_rect.center)
    
    if mode != "singleplayer" and mode != "vs_ai":
        cage.active = False 
    elif mode == "singleplayer" and level_num < 4:
         pass

    game_state = "playing"
    winner_text = ""
    win_timer = 0
    win_sound_played = False
    
    running = True
    while running:
        clock.tick(FPS); await asyncio.sleep(0)
        screen.fill(BLACK)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return "menu", 0, 0

        if game_state == "playing":
            keys = pygame.key.get_pressed()
            player.update(keys, platforms, ladders, target_rect, coins)
            
            if bot_player: 
                bot_target = target_rect if not cage.active else None
                bot_player.update(keys, platforms, ladders, bot_target, coins)
            
            if pauline: pauline.update()
            dk.update_ai(barrels, fires, level_num)
            fires.update(platforms)
            
            # --- COIN COLLECTION (UPDATED) ---
            collected_by_p1 = pygame.sprite.spritecollide(player, coins, True)
            if collected_by_p1:
                p1_coins_collected += len(collected_by_p1) # Track count
                if GAME_SETTINGS["sound"] and SND_COIN: SND_COIN.play()
                score += 100 * len(collected_by_p1)

            if bot_player:
                collected_by_bot = pygame.sprite.spritecollide(bot_player, coins, True)
                if collected_by_bot:
                    bot_coins_collected += len(collected_by_bot) # Track bot count
                    if GAME_SETTINGS["sound"] and SND_COIN: SND_COIN.play()

            # Cage Opening Logic
            if len(coins) == 0:
                cage.active = False

            # Win Check
            target_hit = False
            if not cage.active:
                if player.rect.colliderect(target_rect):
                    if pauline: pauline.is_saved = True
                    target_hit = True; winner_text = "PLAYER 1 WINS!"

            if bot_player and not cage.active:
                if bot_player.rect.colliderect(target_rect):
                    if pauline: pauline.is_saved = True
                    target_hit = True; winner_text = "COMPUTER WINS!"

            if target_hit:
                game_state = "victory_anim"
                dk.start_death()
                win_timer = pygame.time.get_ticks()
                if not win_sound_played:
                    if GAME_SETTINGS["sound"] and SND_WIN: SND_WIN.play()
                    win_sound_played = True

            # Hazards
            for b in barrels:
                b.update(platforms)
                if player.rect.colliderect(b.rect): 
                    lives -= 1; b.kill(); player.rect.topleft = (50, 600)
                if bot_player and bot_player.rect.colliderect(b.rect): 
                    bot_player.lives -= 1; b.kill(); bot_player.rect.topleft = (150, 600)

            for f in fires:
                if player.rect.colliderect(f.rect): 
                    lives -= 1; f.kill(); player.rect.topleft = (50, 600)
                if bot_player and bot_player.rect.colliderect(f.rect):
                    bot_player.lives -= 1; f.kill(); bot_player.rect.topleft = (150, 600)

            if lives <= 0:
                 game_state = "game_over"
                 if GAME_SETTINGS["sound"] and SND_GAMEOVER: SND_GAMEOVER.play()

            if bot_player and bot_player.lives <= 0:
                winner_text = "PLAYER 1 WINS!"
                game_state = "victory_anim"
                dk.start_death()
                win_timer = pygame.time.get_ticks()

        elif game_state == "victory_anim":
            dk.update_death_anim()
            if pauline: pauline.update()
            if pygame.time.get_ticks() - win_timer > 2000:
                if mode == "vs_ai" and winner_text == "COMPUTER WINS!": return "menu", score, lives 
                if level_num == 4: return "game_beaten", score, lives, optimal_moves
                return "won", score, lives, optimal_moves

        elif game_state == "game_over":
            over_txt = TITLE_FONT.render("GAME OVER", True, RED)
            screen.blit(over_txt, (WIDTH//2 - over_txt.get_width()//2, HEIGHT//2))
            pygame.display.update(); await asyncio.sleep(3); return "menu", 0, 0

        # Draw
        for p in platforms: p.draw(screen)
        for l in ladders: screen.blit(l.image, l.rect)
        dk.draw(screen)
        if pauline: pauline.draw(screen)
        cage.draw(screen)
        for b in barrels: b.draw(screen)
        for f in fires: f.draw(screen)
        for c in coins: screen.blit(c.image, c.rect)
        player.draw(screen)
        if bot_player: bot_player.draw(screen)
        
        # --- NEW UI CALL ---
        # This replaces the old messy text blocks
        bot_lives = bot_player.lives if bot_player else 0
        draw_hud(screen, mode, lives, p1_coins_collected, score, bot_lives, bot_coins_collected)

        # Status Text for Cage (MOVED TO BOTTOM)
        if not cage.active and game_state == "playing":
             txt_open = HUD_FONT.render(f"CAGE OPEN! GO TO TOP!", True, GREEN_NEON)
             # Position set to Bottom Middle (HEIGHT - 80)
             screen.blit(txt_open, (WIDTH//2 - txt_open.get_width()//2, HEIGHT - 80))

        if winner_text and game_state == "victory_anim":
            txt_win = TITLE_FONT.render(winner_text, True, GREEN_NEON)
            screen.blit(txt_win, (WIDTH//2 - txt_win.get_width()//2, HEIGHT//2))

        pygame.display.update()

class Barrel(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.frames = []
        for i in range(1, 5):
            path = os.path.join(BARREL_DIR, f"roll_{i}.png")
            self.frames.append(load_sprite(path, 30, 30, ORANGE))
        if not self.frames: 
            # Fallback if images are missing
            s = pygame.Surface((30,30))
            s.fill(ORANGE)
            self.frames = [s]

        self.frame_index = 0
        self.image = self.frames[0]
        self.rect = self.image.get_rect(topleft=(x, y))
        self.vel_y = 0; self.vel_x = 0; self.gravity = 0.5; self.dragging = False
        self.scored = False 

    def update(self, platforms):
        self.frame_index += 0.2
        if self.frame_index >= len(self.frames): self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]

        if self.dragging:
            mx, my = pygame.mouse.get_pos()
            self.rect.center = (mx, my)
            self.vel_y = 0 
        else:
            self.vel_y += self.gravity
            self.rect.x += self.vel_x 
            self.rect.y += self.vel_y
            
            for plat in platforms:
                if self.rect.colliderect(plat.rect):
                    if self.vel_y > 0: 
                        self.rect.bottom = plat.rect.top
                        self.vel_y = 0

            if self.rect.y > 600:
                 if self.rect.right < 0 or self.rect.left > WIDTH: self.kill()
            else:
                if self.rect.right > WIDTH: self.rect.right = WIDTH; self.vel_x *= -1 
                elif self.rect.left < 0: self.rect.left = 0; self.vel_x *= -1 

            if self.rect.top > HEIGHT: self.kill()

    def draw(self, surf):
        surf.blit(self.image, self.rect)

class DonkeyKong(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.sprites = {}
        states = ["idle", "hold", "beat_l", "beat_r", "roll_l", "roll_r"]
        for s in states:
            self.sprites[s] = load_sprite(os.path.join(DK_DIR, f"{s}.png"), 90, 90, PURPLE)
        
        self.death_anim = []
        for i in range(1, 6):
            self.death_anim.append(load_sprite(os.path.join(DK_DIR, f"dead_{i}.png"), 90, 90, PURPLE))

        self.state = "idle"
        self.image = self.sprites["idle"]
        self.rect = self.image.get_rect(topleft=(x, y))
        self.speed = 8; self.facing_right = False
        self.barrels_thrown = 0; self.last_throw_dir = -1
        self.is_dying = False; self.death_frame = 0; self.death_timer = 0
        self.last_fire_time = 0

    def start_death(self):
        if not self.is_dying:
            self.is_dying = True; self.death_frame = 0; self.death_timer = pygame.time.get_ticks()

    def update_ai(self, barrels_group, fires_group, current_level):
        if self.is_dying: return # Stop attacking if dying
        
        curr_time = pygame.time.get_ticks()
        loop_time = (curr_time / 1000) % 15 
        
        if 3 <= loop_time < 7:
            beat_phase = (curr_time // 500) % 2
            self.image = self.sprites["beat_l"] if beat_phase == 0 else self.sprites["beat_r"]
            if current_level == 4:
                if curr_time - self.last_fire_time > 800:
                    f = Fire(self.rect.centerx, self.rect.bottom)
                    fires_group.add(f)
                    self.last_fire_time = curr_time
        elif 0 <= loop_time < 3:
            self.image = self.sprites["idle"]
            self.barrels_thrown = 0
        elif 7 <= loop_time < 9:
            self.image = self.sprites["hold"]
        elif 9 <= loop_time < 15:
            throw_slot = int((loop_time - 9) / 2) 
            if self.barrels_thrown <= throw_slot:
                self.barrels_thrown += 1
                throw_dir = random.choice([-1, 1])
                self.last_throw_dir = throw_dir
                new_barrel = Barrel(self.rect.centerx, self.rect.bottom - 35)
                new_barrel.vel_x = throw_dir * 4 
                barrels_group.add(new_barrel)
                if GAME_SETTINGS["sound"] and SND_BARREL: SND_BARREL.play()
            
            if self.last_throw_dir == 1: self.image = self.sprites["roll_r"]
            else: self.image = self.sprites["roll_l"]

    def update(self, keys): 
        if keys[pygame.K_LEFT]: self.rect.x -= self.speed; self.facing_right = False
        if keys[pygame.K_RIGHT]: self.rect.x += self.speed; self.facing_right = True
        self.image = self.sprites["roll_r"] if self.facing_right else self.sprites["roll_l"]

    def update_death_anim(self):
        # Handles playing the animation then deleting the sprite
        curr_time = pygame.time.get_ticks()
        if curr_time - self.death_timer > 150:
            self.death_frame += 1
            self.death_timer = curr_time
        
        if self.death_frame < len(self.death_anim):
            self.image = self.death_anim[self.death_frame]
        else:
            self.kill() # VANISH LOGIC: Removes DK from all groups

    def draw(self, surf):
        # Only draw if he hasn't vanished (alive or mid-animation)
        if not self.is_dying or (self.is_dying and self.death_frame < len(self.death_anim)):
             surf.blit(self.image, self.rect)
async def single_player_campaign():
    lvl = 1; score = 0; lives = 3
    while lvl <= 4:
        res = await run_level(lvl, score, lives, mode="singleplayer")
        if len(res) == 4: status, score, lives, opt = res
        else: status, score, lives = res; opt=0

        if status == "menu": return "menu"
        if status == "game_beaten": await game_beaten_screen(score, lives, opt); return "menu"
        if status == "won":
            action = await level_complete_screen(lvl, score, lives, opt)
            if action == "menu": return "menu"
            lvl += 1
    return "menu"

async def vs_ai_mode():
    res = await run_level(1, 0, 3, mode="vs_ai")
    return "menu"

async def run_2p_race_level(level_num):
    # 1. GENERATE MAP & ASSETS
    platforms, ladders = generate_random_level()
    all_sprites = pygame.sprite.Group()
    coins = pygame.sprite.Group()
    barrels = pygame.sprite.Group()
    fires = pygame.sprite.Group()
    
    for p in platforms: all_sprites.add(p)
    for l in ladders: all_sprites.add(l)

    # 2. INITIALIZE PLAYERS
    # Player 1 (Mario Style)
    p1 = Player(50, 600, is_luigi=False)
    # Player 2 (Luigi Style)
    p2 = Player(150, 600, is_luigi=True)
    
    p1_lives = 3
    p2_lives = 3
    
    # Track collected coins separately
    p1_coins_collected = 0
    p2_coins_collected = 0

    # 3. SETUP BOSS & OBJECTIVE
    dk = DonkeyKong(WIDTH//2 - 45, 10)
    pauline = Pauline(dk.rect.x + 100, dk.rect.y + 10)
    
    # CAGE SETUP
    cage_rect = pygame.Rect(pauline.rect.x - 5, pauline.rect.y - 5, pauline.rect.width + 10, pauline.rect.height + 10)
    cage = Cage(cage_rect.x, cage_rect.y, cage_rect.width, cage_rect.height)
    
    # SPAWN COINS
    valid_platforms = [p for p in platforms if 150 < p.rect.y < 650]
    while len(coins) < 20:
        if not valid_platforms: break 
        target_plat = random.choice(valid_platforms)
        new_c = Coin(target_plat)
        if not pygame.sprite.spritecollideany(new_c, coins):
            coins.add(new_c); all_sprites.add(new_c)

    winner = None
    dk_vanished = False
    
    # --- GAME LOOP ---
    while True:
        clock.tick(FPS); await asyncio.sleep(0)
        screen.fill(BLACK)
        
        # EVENT HANDLING
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return "menu"

        if not winner:
            keys = pygame.key.get_pressed()
            
            # UPDATE PLAYERS
            if p1_lives > 0: p1.update(keys, platforms, ladders)
            if p2_lives > 0: p2.update(keys, platforms, ladders)
            
            pauline.update()
            fires.update(platforms)
            
            # UPDATE DK
            if not dk_vanished:
                if dk.is_dying:
                    dk.update_death_anim()
                    if not dk.alive(): dk_vanished = True
                else:
                    dk.update_ai(barrels, fires, level_num)
                    dk.draw(screen)

            # --- COIN COLLECTION (SEPARATE TRACKING) ---
            if p1_lives > 0:
                hit_list = pygame.sprite.spritecollide(p1, coins, True)
                for c in hit_list:
                    p1_coins_collected += 1
                    if GAME_SETTINGS["sound"] and SND_COIN: SND_COIN.play()
            
            if p2_lives > 0:
                hit_list = pygame.sprite.spritecollide(p2, coins, True)
                for c in hit_list:
                    p2_coins_collected += 1
                    if GAME_SETTINGS["sound"] and SND_COIN: SND_COIN.play()

            # --- UNLOCK CAGE ---
            # Cage opens when ALL coins on the map are gone
            if len(coins) == 0 and cage.active:
                cage.active = False
                dk.start_death()
                if GAME_SETTINGS["sound"] and SND_WIN: SND_WIN.play()

            # --- WIN CONDITION ---
            if not cage.active:
                if p1_lives > 0 and p1.rect.colliderect(pauline.rect): 
                    winner = "PLAYER 1 WINS!"
                elif p2_lives > 0 and p2.rect.colliderect(pauline.rect): 
                    winner = "PLAYER 2 WINS!"
                
                if winner and GAME_SETTINGS["sound"] and SND_WIN: SND_WIN.play()

            # --- HAZARDS ---
            for b in barrels:
                b.update(platforms)
                # Player 1 Hit
                if p1_lives > 0 and b.rect.colliderect(p1.rect): 
                    p1_lives -= 1; b.kill(); p1.rect.topleft = (50, 600)
                # Player 2 Hit
                if p2_lives > 0 and b.rect.colliderect(p2.rect): 
                    p2_lives -= 1; b.kill(); p2.rect.topleft = (150, 600)
            
            for f in fires:
                # Player 1 Hit
                if p1_lives > 0 and f.rect.colliderect(p1.rect): 
                    p1_lives -= 1; f.kill(); p1.rect.topleft = (50, 600)
                # Player 2 Hit
                if p2_lives > 0 and f.rect.colliderect(p2.rect): 
                    p2_lives -= 1; f.kill(); p2.rect.topleft = (150, 600)

            # --- BOUNDS CHECK (Fell off map) ---
            if p1.rect.top > HEIGHT: p1.rect.topleft = (50, 600); p1_lives -= 1
            if p2.rect.top > HEIGHT: p2.rect.topleft = (150, 600); p2_lives -= 1
            
            # --- DOUBLE GAME OVER CHECK ---
            if p1_lives <= 0 and p2_lives <= 0:
                 winner = "GAME OVER (DRAW)"

        # --- DRAWING ---
        for p in platforms: p.draw(screen)
        for l in ladders: screen.blit(l.image, l.rect)
        if not dk_vanished: dk.draw(screen)
        pauline.draw(screen)
        cage.draw(screen)
        for b in barrels: b.draw(screen)
        for f in fires: f.draw(screen)
        for c in coins: screen.blit(c.image, c.rect)
        
        # Draw Players (only if alive)
        if p1_lives > 0: p1.draw(screen)
        if p2_lives > 0: p2.draw(screen)
        
        # --- UI DRAWING CALL ---
        draw_hud(screen, "race_mode", p1_lives, p1_coins_collected, 0, p2_lives, p2_coins_collected)

        # Handle Win/Loss Screen Overlay
        if winner:
            txt = TITLE_FONT.render(winner, True, GREEN_NEON)
            screen.blit(txt, (WIDTH//2 - txt.get_width()//2, HEIGHT//2))
            pygame.display.update()
            await asyncio.sleep(3)
            return "menu"

        pygame.display.update()

async def settings_menu():
    global screen
    while True:
        txt_fs = "FULLSCREEN: F11 (BROWSER)" if sys.platform == "emscripten" else f"FULLSCREEN: {'ON' if GAME_SETTINGS['fullscreen'] else 'OFF'}"
        txt_snd = f"SOUND: {'ON' if GAME_SETTINGS['sound'] else 'OFF'}"
        
        fs_btn = RPGButton(txt_fs, WIDTH//2 - 225, 200)
        snd_btn = RPGButton(txt_snd, WIDTH//2 - 225, 290)
        htp_btn = RPGButton("HOW TO PLAY", WIDTH//2 - 225, 380)
        crd_btn = RPGButton("CREDITS", WIDTH//2 - 225, 470)
        back_btn = RPGButton("BACK", WIDTH//2 - 225, 560)

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
        draw_dynamic_background(screen)
        title = TITLE_FONT.render("SETTINGS", True, YELLOW)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 80))
        
        fs_btn.draw(screen); snd_btn.draw(screen)
        htp_btn.draw(screen); crd_btn.draw(screen); back_btn.draw(screen)

        if back_btn.clicked(): return "menu"
        if htp_btn.clicked(): await how_to_play_screen()
        if crd_btn.clicked(): await credits_screen()
        if fs_btn.clicked():
            if sys.platform != "emscripten":
                GAME_SETTINGS["fullscreen"] = not GAME_SETTINGS["fullscreen"]
                if GAME_SETTINGS["fullscreen"]: screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)
                else: screen = pygame.display.set_mode((WIDTH, HEIGHT))
        if snd_btn.clicked():
            GAME_SETTINGS["sound"] = not GAME_SETTINGS["sound"]
            if GAME_SETTINGS["sound"]: pygame.mixer.music.unpause()
            else: pygame.mixer.music.pause()
        pygame.display.update(); clock.tick(FPS); await asyncio.sleep(0)

async def mode_select():
    sp_btn = RPGButton("1 PLAYER", WIDTH//2 - 225, 250)
    ai_btn = RPGButton("VS COMPUTER (AI)", WIDTH//2 - 225, 340)
    tp_btn = RPGButton("2 PLAYER (RACE)", WIDTH//2 - 225, 430)
    back_btn = RPGButton("BACK", WIDTH//2 - 225, 520)
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
        draw_dynamic_background(screen); title = TITLE_FONT.render("SELECT MODE", True, YELLOW)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 150))
        
        sp_btn.draw(screen); ai_btn.draw(screen)
        tp_btn.draw(screen); back_btn.draw(screen)
        
        if sp_btn.clicked(): return "singleplayer"
        if ai_btn.clicked(): return "vs_ai"
        if tp_btn.clicked(): return "race_mode"
        if back_btn.clicked(): return "menu"
        pygame.display.update(); clock.tick(FPS); await asyncio.sleep(0)

async def main_menu():
    play_btn = RPGButton("PLAY GAME", WIDTH//2 - 225, 350); set_btn = RPGButton("SETTINGS", WIDTH//2 - 225, 440); quit_btn = RPGButton("QUIT", WIDTH//2 - 225, 530)
    y_off = 0; direction = 0.5
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
        draw_dynamic_background(screen); y_off += direction
        if y_off > 10 or y_off < -10: direction *= -1
        t1 = TITLE_FONT.render("DONKEY KONG", True, YELLOW); t2 = SUBTITLE_FONT.render("(DSA Edition)", True, WHITE)
        screen.blit(t1, (WIDTH//2 - t1.get_width()//2, 120 + y_off)); screen.blit(t2, (WIDTH//2 - t2.get_width()//2, 200 + y_off))
        play_btn.draw(screen); set_btn.draw(screen); quit_btn.draw(screen)
        if play_btn.clicked(): return "mode_select"
        if set_btn.clicked(): return "settings"
        if quit_btn.clicked(): pygame.quit(); sys.exit()
        pygame.display.update(); clock.tick(FPS); await asyncio.sleep(0)

async def main():
    curr = "menu"
    while True:
        if curr == "menu": curr = await main_menu()
        elif curr == "settings": curr = await settings_menu()
        elif curr == "mode_select": curr = await mode_select()
        elif curr == "singleplayer": curr = await single_player_campaign()
        elif curr == "vs_ai": curr = await vs_ai_mode()
        elif curr == "race_mode": curr = await run_2p_race_level(1)

asyncio.run(main())
